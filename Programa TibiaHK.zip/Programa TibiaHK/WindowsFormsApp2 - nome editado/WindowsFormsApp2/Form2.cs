﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TibiaHK
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://support.microsoft.com/pt-br/help/14201/windows-show-hidden-files");
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Form1 _f2;
            _f2 = new Form1();
            _f2.Show();
            Hide();
        }
    }
}
