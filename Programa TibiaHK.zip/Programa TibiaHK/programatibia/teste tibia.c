#include <stdlib.h>
#include <stdio.h>
#include <windows.h>


void main()
{
    char guardar[500][1000], diretorio;
    int j=0, n=0;
    FILE *ler;

    ler = fopen("HT Druid\\Tibia.cfg","r");

    while(fgets(guardar[j],1000,ler)!=NULL)
    {
        j++;
        n++;
    }

    ler = fopen("C:\\Users\\Cezaar\\AppData\\Roaming\\MeTibia\\Tibia.cfg","w");
    fclose(ler);


    for(j=0; j<=n; j++)
    {
        ler = fopen("C:\\Users\\Cezaar\\AppData\\Roaming\\MeTibia\\Tibia.cfg","a");
        guardar[j][strcspn(guardar[j], "\n")] = 0;
        fprintf(ler,"%s\n",guardar[j]);
        fclose(ler);
    }

    system("Tibia.lnk");
    exit(0);

}
