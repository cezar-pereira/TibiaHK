﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Threading;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        private string diretoriocfg;
        private string diretoriotibia;
        private string diretorioelf;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
              DialogResult result = folderBrowserDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                diretoriocfg = folderBrowserDialog1.SelectedPath;
                System.IO.File.WriteAllText("Diretoriocfg.txt", diretoriocfg);// CERTO
                //System.IO.File.WriteAllText("Diretorio.txt", diretoriocfg);
            }
              Console.WriteLine(result); // <-- For debugging use.
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog2.ShowDialog();
            if (result == DialogResult.OK) // Test result.
            {
                diretoriotibia = openFileDialog2.FileName;
                 System.IO.File.WriteAllText("Diretoriotibia.txt", diretoriotibia); // CERTO
                //System.IO.File.WriteAllText("Diretorio.txt", diretoriotibia);
            }
            Console.WriteLine(result); // <-- For debugging use.
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog3.ShowDialog();
            if (result == DialogResult.OK) // Test result.
            {
                diretorioelf = openFileDialog3.FileName;
                 System.IO.File.WriteAllText("Diretorioelf.txt", diretorioelf);// CERTO
               // System.IO.File.Replace("Diretorio.txt", diretorioelf);
            }
            Console.WriteLine(result); // <-- For debugging use.
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Form2 _f2;
            _f2 = new Form2();
            _f2.Show();
            Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            string lercfg = System.IO.File.ReadAllText("diretoriocfg.txt"); //ler e guardar pasta do tibia.cfg

            string fileName = "Tibia.cfg";
            string sourcePath = "HK_Paladin";
            string targetPath = lercfg;
            string sourceFile = System.IO.Path.Combine(sourcePath, fileName);
            string destFile = System.IO.Path.Combine(targetPath, fileName);  
            System.IO.File.Copy(sourceFile, destFile, true);

            string lertibia = System.IO.File.ReadAllText("diretoriotibia.txt");
            System.Diagnostics.Process.Start(lertibia);
            
            if (checkBox1.Checked)
            {
                string lerelf = System.IO.File.ReadAllText("diretorioelf.txt");
                Thread.Sleep(1000);
                System.Diagnostics.Process.Start(lerelf);
            }

            //File.Copy(@"HK_Paladin\Tibia.cfg",lercfg +\\Tibia.cfg,true);
            //textBox1.Text = lerelf; //a textbox esta recebendo o diretorio do diretorioelf
            //string lertibia = System.IO.File.ReadAllText(@"diretoriotibia.txt");
            // System.Diagnostics.Process.Start(@"lertibia");
        }

        private void openFileDialog3_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            string lercfg = System.IO.File.ReadAllText("diretoriocfg.txt"); //ler e guardar pasta do tibia.cfg

            string fileName = "Tibia.cfg";
            string sourcePath = "HK_Knight";
            string targetPath = lercfg;
            string sourceFile = System.IO.Path.Combine(sourcePath, fileName);
            string destFile = System.IO.Path.Combine(targetPath, fileName);
            System.IO.File.Copy(sourceFile, destFile, true);

            string lertibia = System.IO.File.ReadAllText("diretoriotibia.txt");
            System.Diagnostics.Process.Start(lertibia);

            if (checkBox1.Checked)
            {
                string lerelf = System.IO.File.ReadAllText("diretorioelf.txt");
                Thread.Sleep(1000);
                System.Diagnostics.Process.Start(lerelf);
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            string lercfg = System.IO.File.ReadAllText("diretoriocfg.txt"); //ler e guardar pasta do tibia.cfg

            string fileName = "Tibia.cfg";
            string sourcePath = "HK_Sorcerer";
            string targetPath = lercfg;
            string sourceFile = System.IO.Path.Combine(sourcePath, fileName);
            string destFile = System.IO.Path.Combine(targetPath, fileName);
            System.IO.File.Copy(sourceFile, destFile, true);

            string lertibia = System.IO.File.ReadAllText("diretoriotibia.txt");
            System.Diagnostics.Process.Start(lertibia);

            if (checkBox1.Checked)
            {
                string lerelf = System.IO.File.ReadAllText("diretorioelf.txt");
                Thread.Sleep(1000);
                System.Diagnostics.Process.Start(lerelf);
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            string lercfg = System.IO.File.ReadAllText("diretoriocfg.txt"); //ler e guardar pasta do tibia.cfg

            string fileName = "Tibia.cfg";
            string sourcePath = "HK_Druid";
            string targetPath = lercfg;
            string sourceFile = System.IO.Path.Combine(sourcePath, fileName);
            string destFile = System.IO.Path.Combine(targetPath, fileName);
            System.IO.File.Copy(sourceFile, destFile, true);

            string lertibia = System.IO.File.ReadAllText("diretoriotibia.txt");
            System.Diagnostics.Process.Start(lertibia);

            if (checkBox1.Checked)
            {
                string lerelf = System.IO.File.ReadAllText("diretorioelf.txt");
                Thread.Sleep(1000);
                System.Diagnostics.Process.Start(lerelf);
            }
        }
    }
}
